﻿using Microsoft.AspNetCore.Mvc;

namespace Proyecto_CEMP.Controllers
{
    public class ProfesorController : Controller
    {
        public IActionResult CursosAsignados()
        {
            return View();
        }

        public IActionResult GestionTareas()
        {
            return View();
        }

        public IActionResult Calificaciones()
        {
            return View();
        }

        public IActionResult Notificaciones()
        {
            return View();
        }
        public IActionResult Retroalimentacion()
        {
            return View();
        }
        public IActionResult RegistroEntregas()
        {
            return View();
        }
        public IActionResult DatosContacto()
        {
            return View();
        }
        public IActionResult ControlAsistencia()
        {
            return View();
        }
    }
}

