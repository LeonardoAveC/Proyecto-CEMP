﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoCEMP.Controllers
{
    public class AccesoController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }
    }
}

