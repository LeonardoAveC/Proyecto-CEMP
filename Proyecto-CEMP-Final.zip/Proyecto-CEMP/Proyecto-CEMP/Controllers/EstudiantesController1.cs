﻿using Microsoft.AspNetCore.Mvc;

namespace Proyecto_CEMP.Controllers
{
    public class EstudiantesController : Controller
    {

        public IActionResult MisCursos()
        {
            return View();
        }

        public IActionResult Tareas()
        {
            return View();
        }

        public IActionResult Calificaciones()
        {
            return View();
        }

        public IActionResult Notificaciones()
        {
            return View();
        }
        public IActionResult MaterialesClase()
        {
            return View();
        }

    }
}

