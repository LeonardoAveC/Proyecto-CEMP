﻿using Microsoft.AspNetCore.Mvc;

namespace Proyecto_CEMP.Controllers
{
    public class AdministradorController : Controller
    {

        public IActionResult GestionUsuarios()
        {
            return View();
        }

        public IActionResult GestionCursos()
        {
            return View();
        }
       
        public IActionResult GestionProfesores()
        {
            return View();
        }
        
        public IActionResult GestionEstudiantes()
        {
            return View();
        }
        public IActionResult GestionNotificaciones()
        {
            return View();
        }
        public IActionResult Reportes()
        {
            return View();
        }
        public IActionResult GestionVacaciones()
        {
            return View();
        }
    }
}

