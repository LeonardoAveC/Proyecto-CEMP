﻿using Microsoft.AspNetCore.Mvc;

namespace ProyectoCEMP.Controllers
{
    public class PerfilController : Controller
    {
        public IActionResult Index()
        {
            
            var usuario = new
            {
                Nombre = "Leonardo Avendaño",
                Correo = "leo.avenda@gmail.com",
                Rol = "X-Dependiendo del Usuario"
            };

            return View(usuario);
        }
    }
}

